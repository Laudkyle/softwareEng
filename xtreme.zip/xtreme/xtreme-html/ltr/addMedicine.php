<?php

include_once "connection.php";
$medicinePresent = false;

$name = $_POST["name"];
$quantity = $_POST["quantity"];
$price = $_POST["price"];


$query = "SELECT * FROM pharmacyStock Where medicine ='$name'";
$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $serialNo = $row['serialNo'];
    $medicineInfo = $row['medicineInfo'];
    $type = $row['type'];
}
// Update database
$sql = "UPDATE `pharmacyStock` SET `amount` =amount- $quantity WHERE `pharmacyStock`.`id` = '$id'";
mysqli_query($conn, $sql);

//Check if medicine already exists in database
$query = "SELECT * FROM medicine Where medicine ='$name'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    $sql = "UPDATE `medicine` SET `quantity` =quantity + $quantity WHERE `medicine` = '$name'";
    mysqli_query($conn, $sql);

} else {
    //Insert new medicine into database

    $sqli = "INSERT INTO `medicine` (`id`, `serialNo`, `medicine`, `medicineInfo`, `type`, `price`, `quantity`) VALUES (NULL, '$serialNo', '$name', '$medicineInfo', '$type', '$price', '$quantity');";
    mysqli_query($conn, $sqli);
    echo "success";
}

?>