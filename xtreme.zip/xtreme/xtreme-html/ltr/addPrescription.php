<?php

include_once "connection.php";

$serialNo = $_POST["serialNumber"];
$prescription = $_POST["prescription"];
    //Insert new medicine into database

    $sqli = "INSERT INTO `prescriptions` (`serialNumber`, `prescription`) VALUES ('$serialNo', '$prescription');";
    mysqli_query($conn, $sqli);
    echo "success";

?>