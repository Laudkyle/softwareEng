<?php

include_once "connection.php";

$name = $_POST["name"];
$quantity = $_POST["quantity"];



$query = "SELECT * FROM medicine Where medicine ='$name'";
$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $price = $row['price'];
    $quantity_old =$row['quantity'];
}
$total_cost = $quantity * $price;
// Checking store for availabitity
$checked_quantity = $quantity_old -$quantity;
// Update database
if ($checked_quantity <= 0) {
    echo "Quantity cannot exceed Available Drugs";
} else {
    echo "$checked_quantity remaining";
}

?>