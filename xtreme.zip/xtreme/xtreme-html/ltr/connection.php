<?php
// Database connection parameters
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "xtreme";

// Connect to the database
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>
